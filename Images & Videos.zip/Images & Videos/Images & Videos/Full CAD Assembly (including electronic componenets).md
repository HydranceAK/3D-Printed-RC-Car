<img width="920" height="606" alt="image" src="https://github.com/user-attachments/assets/bd9e9692-2a84-41c8-bc47-300827c1c6bd" />
